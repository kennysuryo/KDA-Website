<?php

//panggil koneksi database
include "config.php";

//Uji jika tombol simpan di klik
if(isset($_POST['bsimpan'])){

    //persiapan simpan data baru
    $simpan = mysqli_query($conn, "INSERT INTO kota_yogyakarta_danurejan (Wilayah, Agama, L, P, Total)
    VALUES ('$_POST[Wilayah]',
            '$_POST[Agama]',
            '$_POST[L]',
            '$_POST[P]',
            '$_POST[Total]')");

    //jika simpan sukses
    if($simpan){
        echo "<script>
                alert('Simpan data sukses!');
                document.location='yogja.php';
              </script>";
    }else{
        echo "<script>
                alert('Simpan data Gagal!');
                document.location='yogja.php';
              </script>";
    }
    
}
