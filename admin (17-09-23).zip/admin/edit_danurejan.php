<!-- Custom fonts for this template-->
<link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

    <!-- CSS Bootstrap website KDA -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">

<?php
// include database connection file
include_once("config.php"); ?>
 <html>


<!-- Edit Lama -->

<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="js/edit.js">
<button id="btnStart" type="button" class="btn btn-primary" data-toggle="modal" data-target="#formModal">Klik Untuk Edit Data Danurejan!</button>

<div id="message">
  Terimakasih telah memperbarui data. >:)
</div>

<div class="modal fade" id="formModal" tabindex="-1" role="dialog" aria-labelledby="formModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title" id="formModalLabel">Kecamatan Danurejan</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="close">
          <span aria-hidden="true">&times;</span>
        </button>
    </div>

    <div class="alert alert-success alert-dismissible fade show d-none my-alert" id="my-alert" role="alert">
        <strong>Selamat!</strong> Data berhasil diperbarui.
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>

      <form id="formAwesome">
        <div class="modal-body">
          <div class="form-group row">
            <label for="firstName" class="col-sm-6 col-form-label">
              Wilayah
            </label>
            <div class="col-sm-6">
              <input type="text" class="form-control" id="firstName" value="<?= $row['Wilayah'] ?>">
            </div>
          </div>
          <div class="form-group row">
            <label for="lastName" class="col-sm-6 col-form-label">
              Agama
            </label>
            <div class="col-sm-6">
              <input type="text" class="form-control" id="lastName" value="<?= $row['Agama'] ?>">
            </div>
          </div>
          <div class="form-group row">
            <label for="number" class="col-sm-6 col-form-label">
              Laki Laki
            </label>
            <div class="col-sm-6">
              <input type="number" class="form-control" id="number" value=<?php echo $L;?> >
            </div>
          </div>
          <div class="form-group row">
            <label for="number" class="col-sm-6 col-form-label">
              Perempuan
            </label>
            <div class="col-sm-6">
              <input type="number" class="form-control" id="number" value=<?php echo $P;?>>
            </div>
          </div>
          <div class="form-group row">
            <label for="email" class="col-sm-6 col-form-label">
              Total
            </label>
            <div class="col-sm-6">
              <input type="email" class="form-control" id="email" placeholder=<?php $Total;?> aria-label="Disabled input example" value=<?php 
              $Total= $L+$P ?>
              <?php if ($Total > 0) {
                echo $Total;}?> disabled >
            </div>
          </div>
          <div class="form-group row">
            <label for="awesomeness" class="col-sm-6 col-form-label">
              Is this an awesome form?</label>
            <div class="col-sm-6">
              <select class="form-control" id="awesomeness">
                <option>Yes</option>
                <option>No</option>
              </select>
            </div>
          </div>
          <div class="form-check">
            <input class="form-check-input" type="checkbox" value="" id="awesomeCheck" required>
            <label class="form-check-label" for="awesomeCheck">
              I confirm that I am an awesome person.
            </label>
          </div>
        </div>
        <div class="modal-footer">
            <input type="hidden" name="id" value=<?php echo $_GET ['id'];?>></input>
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn-primary" id="btn-submit" href="yogja.php">Submit</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
    const eventSubmitComplete = new Event('submit-complete');
    const myAlert = document.getElementById('my-alert');
    const btnSubmit = document.getElementById('btn-submit');

    document.addEventListener('submit-complete', function(e){
        myAalert.style.display = "flex";
    });

    btnSubmit.addEventListener('click', function(e){
        document.dispatchEvent(eventSubmitComplete);
    });
</script>

 <!-- Bootstrap core JavaScript-->
 <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Javascript Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous">
    </script>
</body>

</html>