<?php
// include database connection file
include_once("config_ibadah.php");
 
// Get id from URL to delete that user
$id = $_GET['id'];
 
// Delete user row from table based on given id
$result = mysqli_query($mysqli, "DELETE FROM kab_gunungkidul_rumah_ibadah_kristen WHERE id=$id");
 
// After delete redirect to Home, so that latest user list will be displayed.
header("Location:kab_gunungkidul_kristen.php");
?>