<?php
// Create database connection using config file
include_once("config_ibadah.php");

// Fetch all users data from database
$result = mysqli_query($mysqli, "SELECT * FROM rumah_ibadah_khonghucu ORDER BY id ASC");
?>
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>KDA-Kemenag Dalam Angka</title>
  <link rel='stylesheet' href='//ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/themes/smoothness/jquery-ui.css'><link rel="stylesheet" href="./style.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/prefixfree/1.0.7/prefixfree.min.js"></script>
  <script src="script.js"></script>

</head>
<body>
<!-- partial:index.partial.html -->
<aside class="sidebar">
  <div id="leftside-navigation" class="nano">

  <ul class="nano-content">
      <li>
      <a href="hindu.php"><i class="fa fa fa-tasks"></i><span>HINDU</span></a>
      </li>

      <li class="sub-menu">
        <a href="kristen.php"><i class="fa fa fa-tasks"></i><span>KRISTEN</span><i class="arrow fa fa-angle-right pull-right"></i></a>
      </li>

      </li>
      <li class="sub-menu">
        <a href="buddha.php"><i class="fa fa fa-tasks"></i><span>BUDDHA</span></i></a>
        
        </li>
      <li class="sub-menu">
        <a href="khatolik.php"><i class="fa fa fa-tasks"></i><span>KATOLIK</span></i></a>
        
        </li>
      <li class="sub-menu">
        <a href="khonghucu.php"><i class="fa fa fa-tasks"></i><span>KONGHUCU</span></i></a>
        
      </li>
      <li class="back">
      <a class="btn-back"><i class="gg-arrow-left-o" style="margin-right:8px; margin-left:-8px"></i><span onclick="goBack()">Kembali</span></a>
      <script>
      function goBack() {
        window.history.back();
      }
      </script>
      </li>
      <li>
      <a href="index.html" class="btn-back"><i class="gg-home-alt" style="margin-right:8px; margin-left:-8px"></i><span>Ke Halaman Utama</span></a>
      </li>
  </div>
</aside>

</div>
<article>
<html>
<body>
<div class="bbody" >
<h2>Agama Khonghucu</h2>
<h6>Digitalisasi Data Penduduk Agama Non Muslim</h6>
<div class="container">
<div class="content">

<table width='100%' border=30 style="border-color:#497174">

<tr>
<th>Nomor</th><th>Rumah Ibadah</th> <th>Jenis</th> <th>Alamat</th> <th>kabupaten</th><th>Option</th>
</tr>
<?php
while($user_data = mysqli_fetch_array($result)) {         
  echo "<tr>";
  echo "<td>".$user_data['id']."</td>";
  echo "<td>".$user_data['Nama_Rumah_Ibadah']."</td>";
  echo "<td>".$user_data['Jenis']."</td>";
  echo "<td>".$user_data['Alamat']."</td>";
  echo "<td>".$user_data['Kab']."</td>";   
  echo "<td><a href='edit_khonghucu.php?id=$user_data[id]' >Edit</a> | <a href='delete_khonghucu.php?id=$user_data[id]'>Delete</a></td></tr>";        
}
?>
</table>          
  </div>
</div>
<a class="face-button" href="file_csv/data_rumah_ibadah/konghucu_diy.csv" download>

  <div class="face-primary">
  <span class="icon fa fa-cloud"></span>
    Unduh File
  </div>
  
  <div class="face-secondary">
    <span class="icon fa fa-hdd-o"></span>
    Unduh 
  </div>

</a>
</div>
</body>
</html>
<!-- partial -->
  <script src='//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='//ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js'></script><script  src="./script.js"></script>

</body>
</html>
