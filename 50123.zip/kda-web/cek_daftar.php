<?php
// mengaktifkan session pada php
session_start();

// menghubungkan php dengan koneksi database
include 'koneksi.php';

// Cek apakah tombol daftar ditekan
if (isset($_POST['daftar'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $level = $_POST['level'];
  
    // Input data ke database
    $daftar = "INSERT INTO users (username, password, level) VALUES ('$username', '$password', '$level')";
    mysqli_query($conn, $daftar);
  
    // Redirect ke halaman login
    header("Location: login.php");
  }
  ?>