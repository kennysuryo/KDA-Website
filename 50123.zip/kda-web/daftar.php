<!DOCTYPE html>
<html>
<head>
  <title>Form Daftar</title>
</head>
<body>
  <h1>Form Daftar</h1>
  <form action="daftar.php" method="post">
    <label for="username">Username:</label><br>
    <input type="text" name="username" id="username"><br>
    <label for="password">Password:</label><br>
    <input type="password" name="password" id="password"><br>
    <label for="level">Level:</label><br>
    <select name="level" id="level">
      <option value="admin">Admin</option>
      <option value="user">User</option>
    </select><br><br>
    <input type="submit" value="Daftar" name="daftar">
  </form>
</body>
</html>